#include <stdio.h>

enum film {Unstoppable=1, Insidious, Us};

int main () {
int film;

printf("Masukkan Nama Film : ");
printf("\n1.Unstoppable\n");
printf("2.Insidious\n");
printf("3.Us\n");

printf("Pilihan Anda : ");
scanf("%d", &film);

if(film==Unstoppable)
{
	printf("film action");
}
else if (film==Insidious)
{
	printf("film horror");
}
else 
{
	printf("film thriller");
}

return 0;
}